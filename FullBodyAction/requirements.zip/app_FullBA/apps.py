from django.apps import AppConfig


class AppFullBAConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_FullBA'
